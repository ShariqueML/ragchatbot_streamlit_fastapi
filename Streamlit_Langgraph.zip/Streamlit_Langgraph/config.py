import re

class Config:
    # Security settings
    RATE_LIMIT_REQUESTS = 100  # Max requests per window
    RATE_LIMIT_WINDOW = 3600  # 1 hour in seconds
    
    # Content moderation settings
    BLACKLIST_WORDS = [
        "password", "credit card", "ssn", "social security", 
        "exploit", "hack", "bypass", "ignore previous", "ignore above",
        "suicide", "self-harm", "kill myself", "hurt myself",
        "bomb", "terrorist", "attack", "shoot", "weapon"
    ]
    
    SUSPICIOUS_PATTERNS = [
        r"(?i)(ignore|disregard).*(previous|above|instructions)",
        r"(?i)(system|assistant).*(prompt|instructions)",
        r"(?i)(as an? ai|you are an? ai)",
        r"(?i)(human|user).*response",
        r"(?i)(role play|pretend|act as)",
        r"(?i)(hack|exploit|vulnerability|bypass)",
        r"(?i)(password|credentials|login|admin)"
    ]
    
    # Allowed topics (optional allowlist approach)
    ALLOWED_TOPICS = [
        "general knowledge", "science", "technology", "history",
        "culture", "education", "creative writing", "programming"
    ]
    
    # Response templates for restricted content
    RESTRICTED_RESPONSES = {
        "injection": "I cannot process this request as it appears to be attempting to manipulate the system.",
        "harmful": "I cannot provide information that may be harmful or dangerous.",
        "sensitive": "I cannot provide sensitive personal or security information.",
        "general": "This request has been restricted due to content policy violations."
    }